signsend
========

Zetakey Sign &amp; Send - Webapp. It captures the signature using HTML5 browser(e.g Zetakey Browser www.zetakey.com) with Canvas support and send to an email address


Author
-------
Jack Wong <jack.wong@zetakey.com>


Source
------
[Latest Source](https://github.com/jackccwong/signsend)


Live Demo
---------
[Live Demo](http://apps.zetakey.com/signsend)

Release Note
-------------
1. upload_file.php 
Use getimagesize instead of imagesx and imagesy.